# Go Rules Tutorial

This is the source code for the Go Rules tutorial that is available here:
https://bazel-contrib.github.io/SIG-rules-authors/go-tutorial.html
