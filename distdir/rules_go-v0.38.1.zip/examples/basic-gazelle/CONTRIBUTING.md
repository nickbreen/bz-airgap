# Go Rules Tutorial

## Updates

Please update both the source code here and the tutorial that is on the gh-pages branch here:
https://github.com/bazel-contrib/SIG-rules-authors/tree/gh-pages.

Updates to this tutorial require two PRs, as there are code block in the gh-pages tutorial mentioned 
above.
