package main

import (
	"fmt"

	"example.com/lib"
)

func main() {
	fmt.Printf("Hello %s!", lib.Name())
}
