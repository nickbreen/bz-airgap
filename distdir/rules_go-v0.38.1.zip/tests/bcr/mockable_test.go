package mockable

var _ Client = (*MockClient)(nil)
