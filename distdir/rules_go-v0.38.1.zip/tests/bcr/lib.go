package lib

func Name() string {
	return "bzlmod"
}
