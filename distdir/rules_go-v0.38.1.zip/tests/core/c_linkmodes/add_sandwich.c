#include "add_sandwich.h"

int add(int a, int b) {
    return a + b;
}
