extern void native_greeting(void);
