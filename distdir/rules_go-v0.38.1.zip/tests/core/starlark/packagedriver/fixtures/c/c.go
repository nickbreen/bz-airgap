package c

import (
	"example.com/a"
	"example.com/b"
)

func C() {
	a.A()
	b.B()
}
