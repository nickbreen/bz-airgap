package b

func B() {
	return
}
