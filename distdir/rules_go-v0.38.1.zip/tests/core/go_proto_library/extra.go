package foo

func Extra() int {
	return 42
}
