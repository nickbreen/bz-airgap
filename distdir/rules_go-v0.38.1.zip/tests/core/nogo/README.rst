Core Go rules tests
===================

This contains tests of the nogo build-time code analysis tool.

Contents
--------

.. Child list start

* `Vet check <vet/README.rst>`_
* `Nogo configuration <config/README.rst>`_
* `nogo analyzers with dependencies <deps/README.rst>`_
* `Custom nogo analyzers <custom/README.rst>`_
* `nogo test with coverage <coverage/README.rst>`_

.. Child list end

