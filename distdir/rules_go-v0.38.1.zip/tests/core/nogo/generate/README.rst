nogo test with generated code
=======================

.. _nogo: /go/nogo.rst

Tests to ensure `nogo`_ interaction with generated code.

empty_test
-------------
Checks that `nogo`_ is not running over the `_empty.go` file that was
generated as part of GoCompilePkg.

