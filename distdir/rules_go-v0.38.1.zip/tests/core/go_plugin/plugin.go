package main

const HelloWorld = "Hello, world!"

func Hi() string { return HelloWorld }

func main() {}
