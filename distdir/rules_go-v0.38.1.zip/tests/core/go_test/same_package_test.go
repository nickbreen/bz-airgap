package same_package

import (
	"testing"
)

func OkTest(t *testing.T) {}
