package qux

var Qux string
