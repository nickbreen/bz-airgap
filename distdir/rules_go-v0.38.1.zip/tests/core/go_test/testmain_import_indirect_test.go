package test_main_test

import "example.com/imports/test_main"

func init() {
	test_main.Updated = true
}
