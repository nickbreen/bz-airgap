#ifdef __cplusplus
extern "C" void PrintCVersion();
#else
void PrintCVersion();
#endif
