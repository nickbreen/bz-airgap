package gen_and_exclude

import _ "github.com/jr_hacker/darwin"
