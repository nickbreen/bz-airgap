package dot_test

import "testing"

func Test(t *testing.T) {}
