//go:build !(go1.15 || go1.14)
//
// ≡ go1.15 && go1.14 == true
package platforms
