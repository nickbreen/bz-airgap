// +build cgo
// +build !appengine
//
// cgo && !appengine == true ∵
// cgo == true && appengine == undefined

package platforms
