//go:build !cgo
// +build !cgo

package platforms
