package platforms

/*
#cgo CFLAGS: -DGENERIC
*/
import "C"
