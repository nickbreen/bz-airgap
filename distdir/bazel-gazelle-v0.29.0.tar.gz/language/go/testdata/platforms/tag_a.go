//go:build amd64
// +build amd64

package platforms
