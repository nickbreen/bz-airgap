package platforms_test

import _ "example.com/repo/platforms"
