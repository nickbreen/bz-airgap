Repository rules
================

`Moved to markdown <./repository.md>`_
